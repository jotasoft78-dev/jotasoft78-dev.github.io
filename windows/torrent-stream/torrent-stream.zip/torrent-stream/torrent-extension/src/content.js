// Content Script - Detecta magnet links en páginas web

function isMagnetLink(href) {
  return href && href.startsWith('magnet:');
}

function createPlayButton(magnetUrl) {
  const btn = document.createElement('button');
  btn.className = 'torrentstream-play-btn';
  btn.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
      <polygon points="5,3 19,12 5,21"/>
    </svg>
    Reproducir
  `;
  btn.style.cssText = `
    display: inline-flex;
    align-items: center;
    gap: 5px;
    margin-left: 8px;
    padding: 3px 10px;
    background: linear-gradient(135deg, #00c6ff, #0072ff);
    color: white;
    border: none;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    vertical-align: middle;
    font-family: system-ui, sans-serif;
    letter-spacing: 0.3px;
    transition: opacity 0.2s, transform 0.1s;
    box-shadow: 0 2px 8px rgba(0,114,255,0.4);
  `;
  
  btn.addEventListener('mouseenter', () => {
    btn.style.opacity = '0.85';
    btn.style.transform = 'scale(1.04)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.opacity = '1';
    btn.style.transform = 'scale(1)';
  });
  
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'openPlayer', magnet: magnetUrl });
  });
  
  return btn;
}

function injectButtons() {
  const links = document.querySelectorAll('a[href]');
  links.forEach(link => {
    if (isMagnetLink(link.href) && !link.dataset.torrentstreamInjected) {
      link.dataset.torrentstreamInjected = 'true';
      const btn = createPlayButton(link.href);
      link.parentNode.insertBefore(btn, link.nextSibling);
    }
  });
}

// Ejecutar al cargar
injectButtons();

// Observer para contenido dinámico
const observer = new MutationObserver(() => injectButtons());
observer.observe(document.body, { childList: true, subtree: true });
