const SERVER = 'http://localhost:9999';

// ─── Helpers ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const video        = $('video');
const overlay      = $('overlay');
const overlayTitle = $('overlay-title');
const overlaySub   = $('overlay-sub');
const progressWrap = $('progress-wrap');
const progressBar  = $('progress-bar');
const statusBadge  = $('status-badge');
const headerTitle  = $('header-title');
const fileListEl   = $('file-list');
const logBox       = $('log-box');

function setBadge(text, type) {
  statusBadge.textContent = text;
  statusBadge.className = 'header-badge badge-' + type;
}
function log(msg, type) {
  logBox.classList.add('visible');
  const line = document.createElement('div');
  if (type) line.className = 'log-' + type;
  line.textContent = '› ' + msg;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
  console.log('[TorrentStream]', msg);
}
function formatSpeed(b) {
  if (b < 1024) return b + ' B/s';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB/s';
  return (b / 1048576).toFixed(2) + ' MB/s';
}
function formatSize(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  if (b < 1073741824) return (b / 1048576).toFixed(2) + ' MB';
  return (b / 1073741824).toFixed(2) + ' GB';
}
function getIcon(name) {
  const ext = name.split('.').pop().toLowerCase();
  return {mp4:'🎬',mkv:'🎬',avi:'🎬',mov:'🎬',webm:'🎬',wmv:'🎬',ts:'🎬',m4v:'🎬',
          mp3:'🎵',flac:'🎵',aac:'🎵',wav:'🎵',
          jpg:'🖼️',jpeg:'🖼️',png:'🖼️',srt:'💬',sub:'💬',pdf:'📄',zip:'📦'}[ext] || '📁';
}
function isVideo(name) { return /\.(mp4|mkv|avi|mov|webm|wmv|m4v|ts|flv)$/i.test(name); }

// ─── File list ────────────────────────────────────────────────────────────────
let activeIndex = -1;
let currentInfoHash = null;
let statsInterval = null;

function renderFiles(files, infoHash) {
  fileListEl.innerHTML = '';
  files.forEach((file, i) => {
    const item = document.createElement('div');
    item.className = 'file-item' + (i === activeIndex ? ' active' : '');
    item.innerHTML =
      '<div class="file-icon">' + getIcon(file.name) + '</div>' +
      '<div class="file-info">' +
        '<div class="file-name">' + file.name + '</div>' +
        '<div class="file-size">' + formatSize(file.length) + '</div>' +
        '<div class="file-progress"><div class="file-progress-bar" id="fpb-' + i + '" style="width:0%"></div></div>' +
      '</div>';
    if (isVideo(file.name)) {
      item.addEventListener('click', () => playStream(infoHash, i, file.name));
    }
    fileListEl.appendChild(item);
  });
}

// ─── Play via HTTP stream ─────────────────────────────────────────────────────
function playStream(infoHash, fileIndex, fileName) {
  activeIndex = fileIndex;
  const streamUrl = SERVER + '/stream/' + infoHash + '/' + fileIndex;
  log('Streaming: ' + fileName, 'ok');
  log('URL: ' + streamUrl, '');
  setBadge('Reproduciendo', 'playing');
  headerTitle.textContent = fileName;

  video.src = streamUrl;
  video.load();

  video.oncanplay = () => {
    overlay.style.display = 'none';
    video.style.display = 'block';
    video.play().catch(e => log('autoplay bloqueado: ' + e.message, 'warn'));
  };

  video.onerror = () => {
    const err = video.error;
    log('Video error code ' + (err ? err.code : '?') + ': ' + (err ? err.message : 'desconocido'), 'err');
  };
}

// ─── Stats polling ────────────────────────────────────────────────────────────
function startStats(infoHash) {
  if (statsInterval) clearInterval(statsInterval);
  statsInterval = setInterval(async () => {
    try {
      const r    = await fetch(SERVER + '/stats/' + infoHash);
      const data = await r.json();
      $('stat-down').textContent     = formatSpeed(data.downloadSpeed || 0);
      $('stat-up').textContent       = formatSpeed(data.uploadSpeed || 0);
      $('stat-peers').textContent    = data.numPeers || 0;
      $('stat-progress').textContent = Math.round((data.progress || 0) * 100) + '%';
      progressBar.style.width        = Math.round((data.progress || 0) * 100) + '%';

      if (video.style.display === 'none') {
        if (!data.numPeers) {
          overlaySub.textContent = 'Conectando con peers (TCP/UDP)...';
        } else {
          overlaySub.textContent = data.numPeers + ' peer(s) · ' +
            formatSpeed(data.downloadSpeed) + ' · ' +
            Math.round((data.progress || 0) * 100) + '%';
        }
      }
    } catch(e) { /* servidor puede no tener stats aún */ }
  }, 1000);
}

// ─── Server check + add torrent ───────────────────────────────────────────────
async function checkServerAndAdd(torrentId, isMagnet) {
  overlayTitle.textContent = 'Conectando al servidor local...';
  overlaySub.textContent   = 'Verificando http://localhost:9999';
  setBadge('Cargando', 'loading');

  // 1. Check server is running
  try {
    const r = await fetch(SERVER + '/status', { signal: AbortSignal.timeout(3000) });
    const s = await r.json();
    log('Servidor OK — WebTorrent ' + (s.version || '?'), 'ok');
  } catch(e) {
    showServerError();
    return;
  }

  // 2. Add torrent
  overlayTitle.textContent = 'Añadiendo torrent...';
  overlaySub.textContent   = 'El servidor está descargando metadatos';

  try {
    let response, data;

    if (isMagnet) {
      response = await fetch(SERVER + '/add', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ magnet: torrentId }),
      });
    } else {
      // torrentId is a Uint8Array
      response = await fetch(SERVER + '/add-file', {
        method:  'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body:    torrentId,
      });
    }

    data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Error del servidor');

    log('Torrent añadido: ' + data.name, 'ok');
    log('Archivos: ' + data.files.length, 'ok');

    currentInfoHash = data.infoHash;
    headerTitle.textContent = data.name;
    renderFiles(data.files, data.infoHash);
    startStats(data.infoHash);

    if (data.streamUrl && data.videoIndex >= 0) {
      const videoFile = data.files[data.videoIndex];
      overlayTitle.textContent = 'Descargando...';
      overlaySub.textContent   = 'Esperando datos para reproducir · 0 peers';
      playStream(data.infoHash, data.videoIndex, videoFile.name);
    } else {
      overlayTitle.textContent = 'Sin video';
      overlaySub.textContent   = 'No se encontraron archivos de video en este torrent';
      log('Sin archivos de video', 'warn');
    }

  } catch(e) {
    log('Error añadiendo torrent: ' + e.message, 'err');
    showError('Error: ' + e.message);
  }
}

// ─── Error screens ────────────────────────────────────────────────────────────
function showServerError() {
  overlay.innerHTML =
    '<div class="error-icon">⚡</div>' +
    '<div class="overlay-title">Servidor no encontrado</div>' +
    '<div class="overlay-sub" style="max-width:340px">' +
      'El servidor local no está corriendo.<br><br>' +
      '<strong>Ábrelo con:</strong><br>' +
      '<code style="background:rgba(255,255,255,.08);padding:6px 10px;border-radius:6px;display:inline-block;margin-top:6px;font-size:11px">' +
        'cd torrent-server<br>npm install<br>node server.js' +
      '</code>' +
    '</div>';
  overlay.style.display = 'flex';
  setBadge('Sin servidor', 'error');
  log('Servidor no responde en localhost:9999', 'err');
}

function showError(msg) {
  overlay.innerHTML =
    '<div class="error-icon">⚠️</div>' +
    '<div class="overlay-title">Error</div>' +
    '<div class="overlay-sub">' + msg + '</div>';
  overlay.style.display = 'flex';
  setBadge('Error', 'error');
}

// ─── Entry point ──────────────────────────────────────────────────────────────
(function init() {
  const hash = window.location.hash.slice(1);
  log('Iniciando TorrentStream...', '');

  if (hash.startsWith('magnet=')) {
    const magnet = decodeURIComponent(hash.slice('magnet='.length));
    log('Magnet: ' + magnet.substring(0, 80), 'ok');
    checkServerAndAdd(magnet, true);

  } else if (hash.startsWith('torrentFile=')) {
    log('Archivo .torrent recibido', 'ok');
    try {
      const binary = atob(decodeURIComponent(hash.slice('torrentFile='.length)));
      const bytes  = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      log('Tamaño: ' + bytes.length + ' bytes', '');
      if (bytes[0] !== 100) {
        showError('Archivo .torrent inválido (primer byte=' + bytes[0] + ')');
        return;
      }
      checkServerAndAdd(bytes, false);
    } catch(e) {
      showError('Error leyendo .torrent: ' + e.message);
    }

  } else {
    showError('No se recibió magnet link ni archivo .torrent.');
    log('Hash: "' + hash + '"', 'err');
  }
})();
