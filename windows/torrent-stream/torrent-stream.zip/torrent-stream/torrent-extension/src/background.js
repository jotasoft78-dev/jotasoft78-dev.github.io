// Background Service Worker - TorrentStream

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'openPlayer' || message.action === 'openPlayerFromPopup') {
    // Pasamos el magnet en el hash (#) para evitar que URLSearchParams
    // lo rompa con los & internos del magnet link
    const playerUrl = chrome.runtime.getURL('player.html') +
      '#magnet=' + encodeURIComponent(message.magnet);
    chrome.tabs.create({ url: playerUrl });
    sendResponse({ success: true });
  }
  return true;
});
