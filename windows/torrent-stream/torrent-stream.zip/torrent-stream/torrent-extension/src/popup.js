const magnetInput = document.getElementById('magnet-input');
const playBtn     = document.getElementById('play-btn');
const fileInput   = document.getElementById('file-input');
const statusEl    = document.getElementById('status');

function showError(msg) {
  statusEl.textContent = msg;
  statusEl.className = 'status error';
}
function hideStatus() { statusEl.className = 'status'; }

function openPlayer(magnet) {
  if (!magnet || !magnet.startsWith('magnet:')) {
    showError('Debe comenzar con "magnet:"');
    return;
  }
  hideStatus();
  chrome.runtime.sendMessage({ action: 'openPlayerFromPopup', magnet });
  window.close();
}

playBtn.addEventListener('click', () => openPlayer(magnetInput.value.trim()));

magnetInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); openPlayer(magnetInput.value.trim()); }
});
magnetInput.addEventListener('input', hideStatus);

// Archivo .torrent: lo pasamos por hash también
fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    // Convertir ArrayBuffer → base64 de forma segura para archivos grandes
    const bytes = new Uint8Array(ev.target.result);
    let binary = '';
    const chunkSize = 8192;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    const base64 = btoa(binary);
    const playerUrl = chrome.runtime.getURL('player.html') +
      '#torrentFile=' + encodeURIComponent(base64);
    chrome.tabs.create({ url: playerUrl });
    window.close();
  };
  reader.readAsArrayBuffer(file);
});

// Detectar magnet en portapapeles
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (text.startsWith('magnet:') && !magnetInput.value) magnetInput.value = text;
  } catch {}
});
