═══════════════════════════════════════════════
  TorrentStream - Servidor Local  v1.0.0
═══════════════════════════════════════════════

REQUISITOS
──────────
  • Node.js 16 o superior
    Descarga: https://nodejs.org

INSTALACIÓN (solo la primera vez)
──────────────────────────────────
  1. Abre una terminal en esta carpeta
  2. Ejecuta:

       npm install

ARRANCAR EL SERVIDOR
─────────────────────
  Cada vez que quieras usar el plugin:

       node server.js

  Verás:
       ╔══════════════════════════════════════╗
       ║   TorrentStream Server  v1.0.0       ║
       ║   http://localhost:9999              ║
       ╚══════════════════════════════════════╝

  Deja esta ventana abierta mientras usas el plugin.

CÓMO FUNCIONA
─────────────
  El servidor descarga el torrent usando TCP/UDP normal
  (igual que qBittorrent) y lo sirve al plugin de Chrome
  por HTTP con soporte de Range requests para seek en video.

  Plugin Chrome → HTTP → Servidor local → TCP/UDP → Seeders

DETENER EL SERVIDOR
────────────────────
  Ctrl+C en la terminal

═══════════════════════════════════════════════
