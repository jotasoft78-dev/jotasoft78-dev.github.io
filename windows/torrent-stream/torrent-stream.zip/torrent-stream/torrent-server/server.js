/**
 * TorrentStream - Servidor Proxy Local
 * 
 * Descarga torrents con webtorrent (TCP+UDP+WebRTC) y los sirve
 * al plugin de Chrome por HTTP con soporte de Range requests
 * para poder hacer seek en el video.
 * 
 * Uso:
 *   npm install
 *   node server.js
 * 
 * Puerto: 9999
 */

const http       = require('http');
const url        = require('url');
const path       = require('path');
const fs         = require('fs');
const WebTorrent = require('webtorrent');

const PORT   = 9999;
const client = new WebTorrent();

// torrents activos: infoHash -> torrent
const torrents = {};

// ─── CORS headers ─────────────────────────────────────────────────────────────
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range');
  res.setHeader('Access-Control-Expose-Headers','Content-Range, Accept-Ranges, Content-Length');
}

// ─── JSON response helper ─────────────────────────────────────────────────────
function json(res, code, obj) {
  cors(res);
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
}

// ─── Find largest video file in torrent ──────────────────────────────────────
function findVideoFile(torrent) {
  const VIDEO = /\.(mp4|mkv|avi|mov|webm|wmv|m4v|ts|flv)$/i;
  return torrent.files
    .filter(f => VIDEO.test(f.name))
    .sort((a, b) => b.length - a.length)[0] || null;
}

// ─── Add torrent and return a promise ─────────────────────────────────────────
function addTorrent(torrentId) {
  return new Promise((resolve, reject) => {
    // Check if already added
    const existing = client.torrents.find(t =>
      t.magnetURI === torrentId ||
      (typeof torrentId === 'string' && t.infoHash === torrentId.toLowerCase()) ||
      t.infoHash === torrentId
    );
    if (existing) return resolve(existing);

    client.add(torrentId, (torrent) => {
      torrents[torrent.infoHash] = torrent;
      resolve(torrent);
    });
    client.on('error', reject);
  });
}

// ─── HTTP Server ──────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  const parsed   = url.parse(req.url, true);
  const pathname = parsed.pathname;

  // OPTIONS preflight
  if (req.method === 'OPTIONS') {
    cors(res);
    res.writeHead(204);
    return res.end();
  }

  console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${pathname}`);

  // ── GET /status ─────────────────────────────────────────────────────────────
  if (pathname === '/status') {
    return json(res, 200, { ok: true, version: '1.0.0', torrents: client.torrents.length });
  }

  // ── POST /add  body: { magnet } or multipart .torrent ────────────────────────
  if (pathname === '/add' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      try {
        const { magnet } = JSON.parse(body);
        if (!magnet) return json(res, 400, { error: 'Falta campo "magnet"' });

        console.log('[ADD] Magnet:', magnet.substring(0, 80) + '...');
        const torrent = await addTorrent(magnet);
        const video   = findVideoFile(torrent);

        return json(res, 200, {
          infoHash:  torrent.infoHash,
          name:      torrent.name,
          files:     torrent.files.map((f, i) => ({
            index:  i,
            name:   f.name,
            length: f.length,
            path:   f.path,
          })),
          videoIndex: video ? torrent.files.indexOf(video) : -1,
          streamUrl:  video
            ? `http://localhost:${PORT}/stream/${torrent.infoHash}/${torrent.files.indexOf(video)}`
            : null,
        });
      } catch(e) {
        console.error('[ADD error]', e.message);
        return json(res, 500, { error: e.message });
      }
    });
    return;
  }

  // ── POST /add-torrent-file  body: raw .torrent bytes ─────────────────────────
  if (pathname === '/add-file' && req.method === 'POST') {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', async () => {
      try {
        const buf     = Buffer.concat(chunks);
        console.log('[ADD-FILE] size:', buf.length, 'bytes');
        const torrent = await addTorrent(buf);
        const video   = findVideoFile(torrent);

        return json(res, 200, {
          infoHash:   torrent.infoHash,
          name:       torrent.name,
          files:      torrent.files.map((f, i) => ({
            index:  i,
            name:   f.name,
            length: f.length,
          })),
          videoIndex: video ? torrent.files.indexOf(video) : -1,
          streamUrl:  video
            ? `http://localhost:${PORT}/stream/${torrent.infoHash}/${torrent.files.indexOf(video)}`
            : null,
        });
      } catch(e) {
        console.error('[ADD-FILE error]', e.message);
        return json(res, 500, { error: e.message });
      }
    });
    return;
  }

  // ── GET /stats/:infoHash ─────────────────────────────────────────────────────
  const statsMatch = pathname.match(/^\/stats\/([a-f0-9]+)$/i);
  if (statsMatch) {
    const torrent = torrents[statsMatch[1].toLowerCase()];
    if (!torrent) return json(res, 404, { error: 'Torrent no encontrado' });
    return json(res, 200, {
      name:          torrent.name,
      progress:      torrent.progress,
      downloadSpeed: torrent.downloadSpeed,
      uploadSpeed:   torrent.uploadSpeed,
      numPeers:      torrent.numPeers,
      downloaded:    torrent.downloaded,
      length:        torrent.length,
      done:          torrent.done,
    });
  }

  // ── GET /stream/:infoHash/:fileIndex ─────────────────────────────────────────
  const streamMatch = pathname.match(/^\/stream\/([a-f0-9]+)\/(\d+)$/i);
  if (streamMatch) {
    const infoHash  = streamMatch[1].toLowerCase();
    const fileIndex = parseInt(streamMatch[2], 10);
    const torrent   = torrents[infoHash];

    if (!torrent) return json(res, 404, { error: 'Torrent no encontrado. Llama a /add primero.' });

    const file = torrent.files[fileIndex];
    if (!file) return json(res, 404, { error: 'Archivo no encontrado en el torrent' });

    const fileLength = file.length;
    const rangeHeader = req.headers['range'];

    cors(res);
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Content-Type', getMimeType(file.name));

    let start = 0;
    let end   = fileLength - 1;

    if (rangeHeader) {
      const match = rangeHeader.match(/bytes=(\d+)-(\d*)/);
      if (match) {
        start = parseInt(match[1], 10);
        end   = match[2] ? parseInt(match[2], 10) : fileLength - 1;
      }
    }

    const chunkSize = end - start + 1;
    console.log(`[STREAM] ${file.name} bytes=${start}-${end}/${fileLength}`);

    res.setHeader('Content-Length', chunkSize);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${fileLength}`);
    res.writeHead(rangeHeader ? 206 : 200);

    // createReadStream on the webtorrent file with byte range
    const stream = file.createReadStream({ start, end });
    stream.pipe(res);

    stream.on('error', (err) => {
      console.error('[STREAM error]', err.message);
      if (!res.headersSent) {
        res.writeHead(500);
        res.end(err.message);
      }
    });

    req.on('close', () => stream.destroy());
    return;
  }

  // ── 404 ──────────────────────────────────────────────────────────────────────
  json(res, 404, { error: 'Ruta no encontrada', rutas: ['/status', '/add', '/add-file', '/stats/:hash', '/stream/:hash/:index'] });
});

// ─── MIME types ───────────────────────────────────────────────────────────────
function getMimeType(filename) {
  const ext = path.extname(filename).toLowerCase();
  const types = {
    '.mp4': 'video/mp4', '.m4v': 'video/mp4',
    '.mkv': 'video/x-matroska', '.webm': 'video/webm',
    '.avi': 'video/x-msvideo', '.mov': 'video/quicktime',
    '.wmv': 'video/x-ms-wmv',  '.ts':  'video/mp2t',
    '.flv': 'video/x-flv',
  };
  return types[ext] || 'application/octet-stream';
}

// ─── Start ────────────────────────────────────────────────────────────────────
server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║   TorrentStream Server  v1.0.0       ║');
  console.log('  ║   http://localhost:' + PORT + '             ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
  console.log('  Servidor listo. Deja esta ventana abierta.');
  console.log('  El plugin de Chrome se conectará automáticamente.');
  console.log('');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  ERROR: El puerto ${PORT} ya está en uso.`);
    console.error('  Cierra la otra instancia del servidor e intenta de nuevo.\n');
  } else {
    console.error('Server error:', err);
  }
  process.exit(1);
});

client.on('error', (err) => console.error('[WebTorrent]', err.message));
